<?php
// contact.php
// Simpel contact form + proses POST, aman untuk tugas (htmlspecialchars)
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>NUBILAB - Contact</title>
  <link rel="stylesheet" href="output.css">
</head>
<body class="bg-gray-100 text-gray-800">

  <!-- Navbar -->
  <nav class="bg-gray-800 text-white p-4 flex justify-between items-center">
    <h1 class="text-xl font-bold">NUBILAB</h1>
    <ul class="flex gap-6">
      <li><a href="index.html" class="hover:text-yellow-400">Home</a></li>
      <li><a href="about.html" class="hover:text-yellow-400">About</a></li>
      <li><a href="service.html" class="hover:text-yellow-400">Services</a></li>
      <li><a href="pricing.html" class="hover:text-yellow-400">Pricing</a></li>
      <li><a href="contact.php" class="hover:text-yellow-400 font-semibold">Contact</a></li>
    </ul>
  </nav>

  <!-- Hero -->
  <section class="text-center py-16 bg-yellow-200">
    <h2 class="text-4xl font-bold">Contact Us</h2>
    <p class="mt-4 text-lg">Kirimkan pertanyaanmu melalui form di bawah ini.</p>
  </section>

  <!-- Contact Form -->
  <section class="max-w-xl mx-auto py-12 px-6 bg-white shadow-md rounded-xl mt-10">
    <form method="POST" action="">
      <label class="block mb-2 font-semibold">Nama</label>
      <input type="text" name="nama" required class="w-full border border-gray-300 rounded-lg p-2 mb-4">

      <label class="block mb-2 font-semibold">Email</label>
      <input type="email" name="email" required class="w-full border border-gray-300 rounded-lg p-2 mb-4">

      <label class="block mb-2 font-semibold">Pesan</label>
      <textarea name="pesan" rows="4" required class="w-full border border-gray-300 rounded-lg p-2 mb-4"></textarea>

      <button type="submit" class="w-full bg-yellow-400 text-gray-900 font-semibold py-2 rounded-lg hover:bg-yellow-500">
        Kirim Pesan
      </button>
    </form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = htmlspecialchars(trim($_POST["nama"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $pesan = htmlspecialchars(trim($_POST["pesan"]));

    echo "<div class='mt-6 bg-green-100 border border-green-400 text-green-800 p-4 rounded-lg'>
            <p><strong>Pesan berhasil dikirim!</strong></p>
            <p>Nama: $nama</p>
            <p>Email: $email</p>
            <p>Pesan: $pesan</p>
          </div>";
}
?>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-800 text-white text-center py-4 mt-10">
    <p>&copy; 2025 NUBILAB. All rights reserved.</p>
  </footer>

  <!-- jQuery (opsional, taruh sebelum </body>) -->
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="script.js"></script>
</body>
</html>
