$(document).ready(function() {
  // Smooth scroll ke atas saat klik logo
  $("h1").click(function() {
    $("html, body").animate({ scrollTop: 0 }, "slow");
  });

  // Animasi fade-in saat scroll
  $(window).on("scroll", function() {
    $(".fade").each(function() {
      var pos = $(this).offset().top;
      var winTop = $(window).scrollTop();
      if (pos < winTop + 600) {
        $(this).addClass("opacity-100 translate-y-0");
      }
    });
  });

  // Alert kecil ketika klik tombol "Pilih Paket"
  $(".hover\\:bg-yellow-500").click(function(e) {
    e.preventDefault();
    alert("Hubungi kami di Contact Page untuk melanjutkan pemesanan!");
  });
});
