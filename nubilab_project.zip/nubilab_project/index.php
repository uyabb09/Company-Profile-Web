<?php

// Memanggil file autoloading dari Composer
require __DIR__ . '/vendor/autoload.php';

// 2. Menggunakan 'use' untuk memanggil namespace
use NubiLab\Layanan\LayananBasic;
use NubiLab\Layanan\LayananPremium;

echo "<h1>Selamat Datang di NUBILAB OOP</h1>";
echo "<hr>";

// Membuat object dari Child Class 1 (LayananBasic)
// (otomatis memanggil __construct() dari Parent)
$tugas1 = new LayananBasic("Mokthar", 50000); // Rp 50k (Basic)

// 3. Implementasi Object Operator (->) pada property public
$tugas1->namaKlien = "Mokthar (Revisi)"; // Mengubah property public
echo "Nama Klien diubah menjadi: " . $tugas1->namaKlien . "<br>";

// 3. Implementasi Object Operator (->) pada method public
echo "ID Tugas: " . $tugas1->getIdTugas() . "<br>";
echo $tugas1->getFitur() . "<br>";
echo "<b>Total Biaya Basic: Rp" . $tugas1->hitungBiayaTotal() . "</b><br>";

// Memanggil magic method __toString()
echo $tugas1; 

// ---------------------------------------------------
echo "<hr>";
// ---------------------------------------------------

// Membuat object dari Child Class 2 (LayananPremium)
$tugas2 = new LayananPremium("Bayu", 200000); // Rp 200k (Premium)
echo "ID Tugas: " . $tugas2->getIdTugas() . "<br>";
echo $tugas2->getFitur() . "<br>";
echo "<b>Total Biaya Premium: Rp" . $tugas2->hitungBiayaTotal() . "</b><br>";

// Memanggil magic method __toString()
echo $tugas2;

// ---------------------------------------------------
echo "<hr>";

// Script selesai, __destruct() akan otomatis dipanggil untuk $tugas1 dan $tugas2
