<?php

// 2. Implementasi Namespace
namespace NubiLab\Layanan;

// 2. Child Class 2 (Inheritance)
class LayananPremium extends LayananTugas {
    
    private $support247 = true;

    // Override method dari parent
    public function hitungBiayaTotal() {
        // Menggunakan property 'protected' $hargaDasar dari parent
        // Ditambah biaya fitur "Premium" (revisi, support, dll)
        $biayaFiturPremium = 25000;
        return $this->hargaDasar + $biayaFiturPremium;
    }

    // Method khusus untuk LayananPremium
    public function getFitur() {
        $statusSupport = $this->support247 ? "Termasuk Support 24/7" : "Tidak ada support";
        return "Fitur: Dokumentasi detail, Free revisi, {$statusSupport}.";
    }
}