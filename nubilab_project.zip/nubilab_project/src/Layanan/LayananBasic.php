<?php

// 2. Implementasi Namespace
namespace NubiLab\Layanan;

// 2. Child Class 1 (Inheritance)
class LayananBasic extends LayananTugas {
    
    // Override method dari parent
    public function hitungBiayaTotal() {
        // Menggunakan property 'protected' $hargaDasar dari parent
        // Ditambah biaya fitur "Basic" (misal: Dokumentasi singkat)
        $biayaFiturBasic = 5000;
        return $this->hargaDasar + $biayaFiturBasic;
    }

    // Method khusus untuk LayananBasic
    public function getFitur() {
        return "Fitur: Dokumentasi singkat.";
    }
}