<?php

// 2. Implementasi Namespace
namespace NubiLab\Layanan;

// 1. Parent Class
class LayananTugas {
    
    // Property public: Bisa diakses dari mana saja (luar class).
    // Alasan: Agar mudah di-set/get oleh object di file index.php.
    public $namaKlien;

    // Property protected: Hanya bisa diakses oleh class ini dan class turunannya (Child).
    // Alasan: Agar Child Class (Basic/Premium) bisa mengambil harga ini 
    //        tapi tidak bisa diubah sembarangan dari luar (index.php).
    protected $hargaDasar;

    // Property private: Hanya bisa diakses oleh class ini.
    // Alasan: Ini adalah data internal rahasia (misal ID unik) 
    //        yang tidak boleh diakses/diketahui oleh Child Class ataupun dari luar.
    private $idTugasInternal;

    
    // METHOD 1 & MAGIC METHOD 1
    public function __construct($namaKlien, $hargaDasar) {
        $this->namaKlien = $namaKlien;
        $this->hargaDasar = $hargaDasar;
        $this->idTugasInternal = uniqid('nubilab_'); // Buat ID unik
        echo "LayananTugas baru untuk {$this->namaKlien} dibuat!<br>";
    }

    // METHOD 2
    // Method public untuk mengambil data private (cara aman)
    public function getIdTugas() {
        return $this->idTugasInternal;
    }

    // METHOD 3
    // Method ini akan kita timpa (override) di Child Class
    public function hitungBiayaTotal() {
        return $this->hargaDasar; // Biaya default
    }

    // METHOD 4 & MAGIC METHOD 2
    public function __toString() {
        return "Info Layanan: Klien {$this->namaKlien}, Harga Dasar: Rp{$this->hargaDasar}<br>";
    }

    // METHOD 5 & MAGIC METHOD 3
    public function __destruct() {
        echo "Layanan untuk {$this->namaKlien} telah selesai diproses.<br><br>";
    }
}