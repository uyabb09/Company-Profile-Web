// script.js (dipakai oleh semua halaman)
// butuh jQuery (sudah disertakan di HTML)

$(document).ready(function() {
  // Smooth scroll ke atas saat klik logo (h1 atau a pertama)
  $("a[href='index.html'], .brand-logo, h1").click(function(e) {
    // jika anchor mengarah ke halaman lain, biarkan.
    // hanya prevent default jika link '#'
    // tetap biarkan default untuk navigasi file html
  });

  // Animasi fade-in saat scroll (kelas .fade dipertahankan jika ada)
  $(window).on("scroll", function() {
    $(".fade").each(function() {
      var pos = $(this).offset().top;
      var winTop = $(window).scrollTop();
      if (pos < winTop + 600) {
        $(this).addClass("opacity-100 translate-y-0");
      }
    });
  });

  // Klik tombol "Pilih Paket" (kelas berupa link di pricing)
  $(document).on("click", ".hover\\:bg-yellow-500, .choose-plan", function(e) {
    // jika link menuju contact, biarkan. Jika untuk demo, tampilkan alert
    if ($(this).attr("href") === "#") {
      e.preventDefault();
    } else {
      // tetap biarkan default (navigasi)
    }
  });

  // MOBILE MENU TOGGLES (simple: buka/tutup menu yang berada di bawah header)
  function bindMobileToggle(btnId, menuId) {
    const btn = document.getElementById(btnId);
    const menu = document.getElementById(menuId);
    if (!btn || !menu) return;
    btn.addEventListener("click", function() {
      menu.classList.toggle("hidden");
    });
  }

  // <-- PERUBAHAN DI SINI: Menyesuaikan ID dengan HTML Anda -->
  // Hapus 5 baris lama (menu-toggle, menu-toggle-2, dst.)
  // Ganti dengan ID yang benar dari file HTML Anda.
  bindMobileToggle("nav-toggle", "nav-mobile"); // Untuk index.html
  bindMobileToggle("nav-toggle-about", "nav-mobile-about"); // Untuk about.html (jika ada)
  bindMobileToggle("nav-toggle-service", "nav-mobile-service"); // Untuk service.html (jika ada)
  bindMobileToggle("nav-toggle-pricing", "nav-mobile-pricing"); // Untuk pricing.html (jika ada)
  bindMobileToggle("nav-toggle-contact", "nav-mobile-contact"); // Untuk contact.html

  // Contact form (tampilkan hasil di UI)
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", function(e) {
      e.preventDefault();
      const nama = document.getElementById("nama").value.trim();
      const email = document.getElementById("email").value.trim();
      const pesan = document.getElementById("pesan").value.trim();
      const resultDiv = document.getElementById("result");
      if (!nama || !email || !pesan) {
        if (resultDiv) {
          resultDiv.classList.remove("hidden");
          resultDiv.innerHTML = "<p class='font-semibold'>Isi semua form dulu.</p>";
        }
        return;
      }

      if (resultDiv) {
        resultDiv.innerHTML = `
          <p><strong>Pesan berhasil dikirim!</strong></p>
          <p>Nama: ${escapeHtml(nama)}</p>
          <p>Email: ${escapeHtml(email)}</p>
          <p>Pesan: ${escapeHtml(pesan)}</p>
        `;
        resultDiv.classList.remove("hidden");
      }

      contactForm.reset();
    });
  }

  // Simple HTML escape
  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }
});

// === FETCH API untuk testimoni (index.html) ===
(function loadTestimonials() {
  const container = document.getElementById("testimoni-container");
  const loader = document.getElementById("testimoni-loader");

  // Fungsi escapeHtml lokal untuk bagian ini (jika diperlukan)
  function escapeHtml(text) {
    return (text + "").replace(/[&<>"']/g, function(m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }

  if (!container) return; // Jika bukan di index.html, berhenti

  fetch("https://jsonplaceholder.typicode.com/comments?_limit=3")
    .then(resp => {
      if (!resp.ok) throw new Error("Network response not ok");
      return resp.json();
    })
    .then(data => {
      // bersihkan container
      container.innerHTML = "";

      data.forEach(item => {
        const card = document.createElement("div");
        card.className = "bg-gray-100 p-6 rounded-xl shadow";
        card.innerHTML = `
          <p class="italic">"${escapeHtml(item.body)}"</p>
          <p class="mt-3 font-semibold text-gray-800">– ${escapeHtml(item.name)}</p>
          <p class="text-sm text-gray-500">${escapeHtml(item.email)}</p>
        `;
        container.appendChild(card);
      });
    })
    .catch(err => {
      if (container) { // Tampilkan error di container jika gagal
        container.innerHTML = "<p class='text-center text-red-500'>Gagal memuat testimoni.</p>";
      }
      console.error("Fetch error:", err);
    })
    .finally(() => {
      // <-- PERUBAHAN UTAMA DI SINI -->
      // .finally() akan selalu berjalan, baik fetch berhasil (then) maupun gagal (catch)
      // Ini adalah tempat terbaik untuk menyembunyikan loader.
      if (loader) {
        loader.style.display = 'none';
      }
    });
})();